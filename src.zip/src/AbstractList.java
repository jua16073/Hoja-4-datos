public abstract class AbstractList<E> implements iPila<E>{
   public AbstractList()
   // post: does nothing
   {
   }


  
  /*public boolean contains(E value)
  // pre: value is not null
  // post: returns true iff list contains an object equal to value
  {
	return -1 != indexOf(value);
  }
  */
}
